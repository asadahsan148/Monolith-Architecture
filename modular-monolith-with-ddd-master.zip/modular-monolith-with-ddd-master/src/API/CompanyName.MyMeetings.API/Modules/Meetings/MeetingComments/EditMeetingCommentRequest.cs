﻿namespace CompanyName.MyMeetings.API.Modules.Meetings.MeetingComments
{
    public class EditMeetingCommentRequest
    {
        public string EditedComment { get; set; }
    }
}