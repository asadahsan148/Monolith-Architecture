﻿namespace CompanyName.MyMeetings.API.Modules.Meetings.Meetings
{
    public class AddMeetingAttendeeRequest
    {
        public int GuestsNumber { get; set; }
    }
}