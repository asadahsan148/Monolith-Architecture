﻿namespace CompanyName.MyMeetings.API.Modules.Meetings.Meetings
{
    public class SetMeetingAttendeeRequest
    {
        public Guid AttendeeId { get; set; }
    }
}