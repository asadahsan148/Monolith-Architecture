﻿namespace CompanyName.MyMeetings.API.Modules.Payments.MeetingFees
{
    public class CreateMeetingFeePaymentRequest
    {
        public Guid MeetingFeeId { get; set; }
    }
}