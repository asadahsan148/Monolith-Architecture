﻿namespace CompanyName.MyMeetings.API.Modules.Payments.MeetingFees
{
    public class RegisterMeetingFeePaymentRequest
    {
        public Guid PaymentId { get; set; }
    }
}