﻿namespace CompanyName.MyMeetings.API.Modules.Payments.Subscriptions
{
    public class RegisterSubscriptionPaymentRequest
    {
        public Guid PaymentId { get; set; }
    }
}