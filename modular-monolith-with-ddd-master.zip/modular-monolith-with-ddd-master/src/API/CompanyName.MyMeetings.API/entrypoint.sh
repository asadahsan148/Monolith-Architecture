#!/bin/bash
sleep 30 ;

dotnet CompanyName.MyMeetings.API.dll