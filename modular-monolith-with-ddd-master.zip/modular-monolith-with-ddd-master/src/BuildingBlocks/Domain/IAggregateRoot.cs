﻿namespace CompanyName.MyMeetings.BuildingBlocks.Domain
{
    public interface IAggregateRoot
    {
    }
}
