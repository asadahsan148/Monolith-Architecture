﻿namespace CompanyName.MyMeetings.Modules.Administration.Application.Contracts
{
    public interface IRecurringCommand
    {
    }
}