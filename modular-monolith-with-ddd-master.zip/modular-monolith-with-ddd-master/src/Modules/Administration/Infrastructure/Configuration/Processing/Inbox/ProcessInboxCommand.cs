﻿using CompanyName.MyMeetings.Modules.Administration.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.Administration.Infrastructure.Configuration.Processing.Inbox
{
    public class ProcessInboxCommand : CommandBase, IRecurringCommand
    {
    }
}