﻿namespace CompanyName.MyMeetings.Modules.Meetings.Application.Contracts
{
    public interface IRecurringCommand
    {
    }
}