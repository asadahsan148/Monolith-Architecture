﻿using CompanyName.MyMeetings.Modules.Meetings.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.MeetingGroups.GetAllMeetingGroups
{
    public class GetAllMeetingGroupsQuery : IQuery<List<MeetingGroupDto>>
    {
    }
}