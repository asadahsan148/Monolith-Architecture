﻿using CompanyName.MyMeetings.Modules.Meetings.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.MeetingGroups.GetAuthenticationMemberMeetingGroups
{
    public class GetAuthenticationMemberMeetingGroupsQuery : QueryBase<List<MemberMeetingGroupDto>>
    {
    }
}